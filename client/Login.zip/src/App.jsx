import React from "react";
import Login from "./component/pages/Login";


const App = () => {
  return <div>
    <Login/>
  </div>;
};

export default App;
