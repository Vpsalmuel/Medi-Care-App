import React from 'react'
import loginImage from '../../asset/login-image.png'
import { useState } from "react";

import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
    const [email, setEmail] = useState()
    const [password, setPassword] = useState()
    const navigate = useNavigate()


    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:3001/login", { email, password })
            .then(result => {
                console.log(result);
                if (result.data === "Login Success") {
                    navigate("/client/src/component/Home.jsx");
                } else if (result.data === "Password didn't match") {
                    console.log("Password is incorrect");
                } else if (result.data === "User not registered") {
                    console.log("User is not registered");
                }
            })
            .catch(err => console.log(err));
    };


    return (
        <div className="bg-image bg-cover bg-center flex lg:bg-none" >
            <form className="bg-gray-200 shadow-md bg- rounded px-8 m-auto pt-6 pb-8 w-[640px] h-[35rem] lg:w-[100%] lg:h-[100%]  opacity-90 " onSubmit={handleSubmit}>
                <h1 className="text-transparent text-center bg-gradient-to-r from-emerald-500 to-lime-300 bg-clip-text  text-[32px] font-normal font-Paytone">MEDI-CARE</h1>
                <h3 className="text-neutral-700  text-center font-Paytone text-xl font-normal">Medical clinic</h3>
                <p className="text-neutral-700 text-[1.5rem] pb-5 pt-5 text-center font-Poppins font-semibold">Login to your account.</p>
                <div className="mb-4 pb-5 lg:max-w-[30rem] m-auto">
                    <label className="block  text-gray-700 text-sm font-bold font-Poppins mb-2" htmlFor="username">
                        Email Address
                    </label>
                    <input className="shadow appearance-none border rounded-[25px]  w-full py-4 px-6 text-gray-700 leading-tight focus:outline-none  focus:shadow-outline" id="email" type="email" placeholder="Example@yourmail.com" onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-6 lg:max-w-[30rem] m-auto m-w">
                    <label className="block text-gray-700 text-sm font-bold font-Poppins mb-2" htmlFor="password">
                        Password
                    </label>
                    <input className="shadow appearance-none border  rounded-[25px]  w-full py-4 px-6 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline" id="password" type="password" placeholder="***********"  onChange={(e) => setPassword(e.target.value)} />

                </div>
                <p className='text-center pb-5'><span className="text-zinc-500 text-[15px] font-Poppins font-normal">Don’t have an account? </span><span className="text-teal-600 text-[15px] font-semibold">Sign up</span></p>
                <div className="flex items-center gap-2 flex-col justify-between lg:max-w-[30rem] m-auto">
                    <button className="text-white text-lg font-semibold w-[100%] h-[47px] font-Poppins px-[78px] py-2.5 bg-gradient-to-r from-emerald-500 to-lime-300 rounded-[25px] -[25px] justify-center items-center gap-2.5 inline-flex focus:outline-none focus:shadow-outline" type="submit">
                        Sign In
                    </button>
                    <a className="inline-block align-baseline font-bold font-Poppins text-sm text-blue-500 hover:text-blue-800" href="#">
                        Forgot Password?
                    </a>
                </div>
            </form>
            <img src={loginImage} alt='' className='hidden lg:block lg:w-[50%] ' />
        </div>


    )
}

export default Login